﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace TankMania
{
    class Missile
    {
        Tacka T, V;
        int power;
        bool build;

        public Missile(Tacka T, Tacka V, int power, bool build = false)
        {
            this.T = T;
            this.V = V;
            this.power = power;
            this.build = build;
        }

        public Tacka K
        {
            get { return T; }
        }
        public int Power
        {
            get { return power; }
        }
        public bool Build
        {
            get { return build; }
        }

        public void Move()
        {
            T = new Tacka(T.X + V.X, T.Y + V.Y);
            V = new Tacka(V.X, (float)(V.Y - 0.15));
        }

        public void Crtaj(Graphics G)
        {
            T.Crtaj(G);
        }
    }
}
