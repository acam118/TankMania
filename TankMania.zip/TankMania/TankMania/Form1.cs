﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TankMania
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Tacka.O = new PointF(0, pictureBox1.Height / 2);
            Tacka.Koef = 3;
            a = new Terrain(pictureBox1);
            a.Generate(tank, (int)numericUpDown1.Value, (int)numericUpDown2.Value);
            pictureBox1.Refresh();
            b = new Missile[100];
            bn = 0;
            Strelica = new Arrow(new Tacka(tank[0].t.X, tank[0].t.Y + 5 * Tacka.Koef));
            moves = maxMoves; label3.Text = moves.ToString();
        }
        Terrain a;
        Missile[] b;
        int bn;
        Tank[] tank = new Tank[2];
        int player = 0;
        Arrow Strelica;
        float sv = (float)(2 * Tacka.Koef);
        int moves; int maxMoves = 5;
        int label5info = 0;
        int label6info = 0;

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            a.Crtaj(e.Graphics);
            for (int i = 0; i < bn; i++)
            {
                b[i].Crtaj(e.Graphics);
            }
            tank[0].Crtaj(e.Graphics, tank[0].a);
            tank[1].Crtaj(e.Graphics, tank[1].a);
            Strelica.Crtaj(e.Graphics);
        }

        //buttons
        #region
        private void button4_Click(object sender, EventArgs e)
        {
            a = new Terrain(pictureBox1);
            a.Generate(tank, (int)numericUpDown1.Value, (int)numericUpDown2.Value);
            Strelica = new Arrow(new Tacka(tank[player].t.X, tank[player].t.Y + 5 * Tacka.Koef));
            pictureBox1.Refresh();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            a.Mountain((int)numericUpDown1.Value, 50);
            pictureBox1.Refresh();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            a.Hole((int)numericUpDown1.Value, 50);
            pictureBox1.Refresh();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            a.Smooth();
            pictureBox1.Refresh();
        }
        
        private void button8_Click(object sender, EventArgs e)
        {
            /*a.Explosion((int)numericUpDown1.Value, 10); //outdated
            pictureBox1.Refresh();*/
        }

        private void button9_Click(object sender, EventArgs e)
        {
            b[bn++] = new Missile(new Tacka(0, a.a[0].Y + 5), new Tacka((float)Math.Sin((int)numericUpDown1.Value * Math.PI / 180) * (float)numericUpDown2.Value / 10, -1 * (float)Math.Cos((int)numericUpDown1.Value * Math.PI / 180) * (float)numericUpDown2.Value / 10), 10); //(float)numericUpDown2.Value / 10, 2
        }

        private void button10_Click(object sender, EventArgs e)
        {
            label5.Text = "10";
            label6.Text = "10";
        }
        #endregion

        private void timer1_Tick(object sender, EventArgs e)
        {
            for (int i = 0; i < bn; i++)
            {
                b[i].Move();
                if (b[i].K.X < 0 || b[i].K.X >= a.N || b[i].K.Y < pictureBox1.Height / -2)
                {
                    b[i] = b[bn - 1];
                    i--;
                    bn--;
                    PlayerEnabled(true);
                }
                else if(a.IspodZemlje(b[i].K))
                {
                    a.Explosion((int)b[i].K.X, b[i]);
                    int d1 = b[i].Power - (int)Math.Floor(tank[0].t.Rastojanje(b[i].K));
                    if(d1 > 0) { label5info += d1; label5.Text = "" + label5info; }
                    int d2 = b[i].Power - (int)Math.Floor(tank[1].t.Rastojanje(b[i].K));
                    if (d2 > 0) { label6info += d2; label6.Text = "" + label6info; }
                    b[i] = b[bn - 1];
                    i--;
                    bn--;
                    tank[0].NamestiY(a);
                    tank[1].NamestiY(a);
                    Strelica = new Arrow(new Tacka(tank[player].t.X, tank[player].t.Y + 5 * Tacka.Koef));
                    PlayerEnabled(true);
                }
            }
            Strelica.T = Strelica.T.Transliraj(0, sv);
            if (Strelica.T.Y < tank[player].t.Y + 5 * Tacka.Koef || Strelica.T.Y > tank[player].t.Y + 10 * Tacka.Koef) sv *= -1;
            Refresh();
        }

        bool aimControl = true;
        public void PlayerEnabled(bool b)
        {
            button1.Enabled = b;
            button2.Enabled = b;
            button3.Enabled = b;
            numericUpDown1.Enabled = b;
            numericUpDown2.Enabled = b;
            aimControl = b;
            if(b) { Strelica.T = new Tacka(tank[player].t.X, tank[player].t.Y + 5 * Tacka.Koef); Strelica.active = true; }
            else Strelica.active = false;
        }

        //controls
        #region
        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.Refresh();
            int P = 50;
            bool build = false;
            if(player == 0)
            {
                if (listBox1.SelectedIndex == 0) P = 10;
                else if (listBox1.SelectedIndex == 1) P = 20;
                else if (listBox1.SelectedIndex == 2) P = 30;
                else if (listBox1.SelectedIndex == 3) P = 40;
                else if (listBox1.SelectedIndex == 4) P = 50;
                else if (listBox1.SelectedIndex == 5) P = 100;
                else if (listBox1.SelectedIndex == 6) build = true;
            }
            else
            {
                if (listBox2.SelectedIndex == 0) P = 10;
                else if (listBox2.SelectedIndex == 1) P = 20;
                else if (listBox2.SelectedIndex == 2) P = 30;
                else if (listBox2.SelectedIndex == 3) P = 40;
                else if (listBox2.SelectedIndex == 4) P = 50;
                else if (listBox2.SelectedIndex == 5) P = 100;
                else if (listBox2.SelectedIndex == 6) build = true;
            }
            b[bn++] = new Missile(new Tacka(tank[player].N, a.a[tank[player].N].Y + 2 * Tacka.Koef), new Tacka((float)Math.Sin((int)numericUpDown1.Value * Math.PI / 180) * (float)numericUpDown2.Value / 10, -1 * (float)Math.Cos((int)numericUpDown1.Value * Math.PI / 180) * (float)numericUpDown2.Value / 10), P, build); //(float)numericUpDown2.Value / 10, 2
            player += 1;
            player %= 2;
            numericUpDown1.Value = tank[player].a;
            numericUpDown2.Value = tank[player].b;
            PlayerEnabled(false);
            moves = maxMoves; label3.Text = moves.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (moves > 0) if (tank[player].N > 5) { tank[player].Pomeri(-5, a); moves--; label3.Text = moves.ToString(); }
            Strelica = new Arrow(new Tacka(tank[player].t.X, tank[player].t.Y + 5 * Tacka.Koef));
            pictureBox1.Refresh();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (moves > 0) if (tank[player].N < a.N - 6) { tank[player].Pomeri(5, a); moves--; label3.Text = moves.ToString(); }
            Strelica = new Arrow(new Tacka(tank[player].t.X, tank[player].t.Y + 5 * Tacka.Koef));
            pictureBox1.Refresh();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            tank[player].a = (int)numericUpDown1.Value;
            pictureBox1.Refresh();
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            tank[player].b = (int)numericUpDown2.Value;
            pictureBox1.Refresh();
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (!aimControl) return;
                float dx = e.X - tank[player].t.izDuG().X;
                float dy = tank[player].t.izDuG().Y - e.Y;
                double theta = Math.Atan2(dy,dx);
                int degree = (int)Math.Ceiling(theta * 180 / Math.PI) + 90;
                degree = (degree + 360) % 360;
                numericUpDown1.Value = degree;
            }
        }
        #endregion
    }
}
